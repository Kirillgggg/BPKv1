API_TOKEN = '7815429800:AAFbxSrHDjV3ONVoIE5rsaYvHDTef03p08Q'

admin = [7305379201, 6465451957, 6400859921]
start_money = 10000000

bot_name = 'BFG'
chat = 't.me/beseda_bfg1'
chanell = 't.me/Bfg49'
admin_username = '@Mon1xGlav'
bot_username = 'bfgcopybot'

chat_log = -1002671526353
cleaning = 60

#8141182611:AAEINU5sJ-4ykhX2wnok8WKtEdfGItErpCA